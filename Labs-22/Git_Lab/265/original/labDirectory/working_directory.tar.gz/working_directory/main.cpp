#include <iostream>
#include "add.h"

using namespace std;

int main(){

    int x,y;
    
    cin>>x>>y;    
    
    cout<<add(x,y)<<"\n";
}