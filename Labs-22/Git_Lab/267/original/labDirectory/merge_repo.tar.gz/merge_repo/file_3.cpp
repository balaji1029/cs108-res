#include <iostream>
#include <set>
#include <algorithm>

using namespace std;

typedef int64_t ll;

int main(){

    ll T;
    cin>>T;

    for(ll I=1;I<=T;I++){

        set<ll> b;
        ll n;
        cin>>n;
        
        for(ll j=0;j<n;j++){

            ll x;
            cin>>x;
            b.insert(x);
        }

        cout<<"{ ";

        for(auto it=b.begin();it!=b.end();it++){
        
            cout<<*it;

            if(it!=prev(b.end())){

                cout<<" | ";
            }
        }
        cout<<" }";
    }
}