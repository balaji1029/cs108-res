#include <iostream>
#include <vector>

using namespace std;

<<<<<<< HEAD
int query(vector<int> &arr, int st, int end){

    return arr[end]-arr[st-1];
=======
int helper(vector<int> &arr, int ind){

    int p=1;

    while(ind>0){
        p*=arr[ind];
        ind-=ind&-ind;
    }

    return p;
}

void update(vector<int> &arr, int st,int val){

    if(st==0){
        return;
    }

    while(st<arr.size()){
        arr[st]*=val;
        st+=st&-st;
    }
}

int query(vector<int> &arr, int st, int end){

    return helper(arr,end)/helper(arr,st-1);
>>>>>>> development
}

int main(){

    vector<int> arr;

    int n;
    cin>>n;

<<<<<<< HEAD
    arr.resize(n+1);

    for(int i=0;i<n;i++){

        cin>>arr[i+1];
    }

    for(int i=1;i<=n;i++){

        arr[i]=arr[i-1]+arr[i];
=======
    arr.resize(n+1,1);

    for(int i=0;i<n;i++){

        int x;
        cin>>x;

        update(arr,i+1,x);
>>>>>>> development
    }

    int q;
    cin>>q;

    for(int i=0;i<q;i++){

        int st,end;
        cin>>st>>end;

        cout<<query(arr,st,end)<<"\n";
    }

}