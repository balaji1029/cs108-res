#include <iostream>
#include <vector>

using namespace std;

int helper(vector<int> &arr, int ind){

    int p=1;

    while(ind>0){
        p*=arr[ind];
        ind-=ind&-ind;
    }

    return p;
}

void update(vector<int> &arr, int st,int val){

    if(st==0){
        return;
    }

    while(st<arr.size()){
        arr[st]*=val;
        st+=st&-st;
    }
}

int query(vector<int> &arr, int st, int end){

    return helper(arr,end)/helper(arr,st-1);
}

int main(){

    vector<int> arr;

    int n;
    cin>>n;

    arr.resize(n+1,1);

    for(int i=0;i<n;i++){

        int x;
        cin>>x;

        update(arr,i+1,x);
    }

    int q;
    cin>>q;

    for(int i=0;i<q;i++){

        int st,end;
        cin>>st>>end;

        cout<<query(arr,st,end)<<"\n";
    }

}